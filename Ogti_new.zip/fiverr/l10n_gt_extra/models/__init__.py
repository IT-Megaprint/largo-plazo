# -*- encoding: utf-8 -*-

from . import account
from . import res_partner
from . import l10n_gt_extra

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
