# -*- encoding: utf-8 -*-

from . import account
from . import res_partner
